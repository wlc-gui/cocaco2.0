import { createRouter, createWebHistory } from 'vue-router';
import Main  from '../views/Main.vue';
import Login from '../views/Login.vue';
import Post from '../views/Post.vue';
import Profile from '../views/Profile.vue';
import { profile } from 'console';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'main',
      component: Main,
    },
    {
      path: '/login',
      name: 'login',
      component: Login,
    },
    {
      path: '/:pathMatch(.*)*', // 모든 경로에 대한 404 페이지 처리
      redirect: '/login', // 기본 경로로 접속하면 로그인 페이지로 리다이렉트라구 합니다람쥐..
                          // 이거 처음에 main페이지 말고 login 페이지 먼저 뜨게 하려구... 한건뎁.. 
    },
    {
      path: '/post',
      name: 'post',
      component: Post,
    },
    {
      path: '/profile',
      name: 'profile',
      component: Profile,
    },
  ],
});

export default router;
router.go()