<template>
    <div class="login-container">
      <h2>로그인</h2>
      <button>Google 계정으로 가입하기</button>
      <div class="divider">또는</div>
      <form @submit.prevent="handleSubmit">
        <div>
          <label for="username">아이디:</label>
          <input type="text" id="username" v-model="username" required />
        </div>
        <div>
          <label for="password">비밀번호:</label>
          <input type="password" id="password" v-model="password" required />
        </div>
        <button type="submit">로그인</button>
      </form>
    </div>
  </template>
  
  <script>
  
  </script>
  
  <style scoped>

  </style>
  