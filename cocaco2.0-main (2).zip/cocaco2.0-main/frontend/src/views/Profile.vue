<template>
    <div> 
      <h1>프로필 페이지</h1>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Profile',

  };
  </script>
  
  <style scoped>
  
  </style>
  