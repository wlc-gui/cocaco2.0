<template>
    <h2>메이이이인페이지</h2>
  </template>
  
  <script>
  
  </script>
  
  <style scoped>

  </style>
  