<template>
    <div id="app">
      <Login /> <!-- Login 컴포넌트를 여기서 사용 -->
    </div>
  </template>
  
  <script>
  import Login from './views/Login.vue'; // login.vue를 import
  
  export default {
    name: 'App',
    components: {
      Login, // 컴포넌트 등록
    },
  };
  </script>
  
  <style>
  /* 필요한 스타일을 추가하세요 */
  </style>
  