
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

const app = createApp(App)

createApp(App).mount('#app'); // #app 요소에 App 컴포넌트를 마운트합니다.

app.use(router)

app.mount('#app')
app.mount('#login')
