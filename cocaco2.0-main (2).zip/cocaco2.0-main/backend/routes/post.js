const express = require('express');
const db = require('../db');
const router = express.Router();

router.post('/', (req, res) => {

});

router.post('/edit', (req, res) => {

});

router.post('/delete', (req, res) => {

});

module.exports = router;